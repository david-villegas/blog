Ejemplo de Blog con Programaci�n en PHP Orientada a Objetos.

Blog de ejemplo con el curso de Platzi.com