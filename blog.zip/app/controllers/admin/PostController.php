<?php  

namespace App\Controllers\Admin;
use App\Controllers\BaseController;
use App\Models\BlogPost;
use Sirius\Validation\Validator;

class PostController extends BaseController
{
	public function getIndex()
	{
		$blogPosts = BlogPost::all();		
	  	return $this->render('admin/posts.twig', ['blogPosts' => $blogPosts]);
	}

	public function getCreate()
	{
		// admin/posts/create
		return $this->render('admin/insert-post.twig');
	}

	public function postCreate()
	{
		$errors = [];
		$result = false;

		$validator = new Validator();
		$validator->add('title', 'required');
		$validator->add('content', 'required');
		$validator->add('image', 'required');

		if ($validator->validate($_POST))
		{
			$blogPosts = new BlogPost([
	    		'title'=> $_POST['title'],
	    		'content' => $_POST['content']
	    		//'image' => $_POST['image']
	  		]);

			if ($_POST['image']) {
				$blogPosts->image = $_POST['image'];
			}

			$blogPosts->save();
			$result= true;
		} else 
			{
				$errors = $validator->getMessages();
				//var_dump($errors);
			}	
		//posts/admin o posts/admin/index
	  return $this->render('admin/insert-post.twig', [
	  	'result' => $result,
	  	'errors' => $errors
	  ]);
	}
}



?>